/*
 * fsm.h
 *
 *  Created on: Nov 9, 2025
 *      Author: Admin
 */

#ifndef INC_FSM_H_
#define INC_FSM_H_
typedef enum {
    CMD_NONE = 0,
    CMD_RST,
    CMD_OK
} Command_t;
#include "stm32f1xx_hal.h"
extern Command_t cmd_flag;
void command_parser_fsm(void);
void uart_communication_fsm(void);

#endif /* INC_FSM_H_ */
