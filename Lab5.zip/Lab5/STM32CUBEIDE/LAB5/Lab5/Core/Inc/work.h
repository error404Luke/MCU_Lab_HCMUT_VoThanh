/*
 * work.h
 *
 *  Created on: Nov 9, 2025
 *      Author: Admin
 */

#ifndef INC_WORK_H_
#define INC_WORK_H_

#include "stm32f1xx_hal.h"

extern UART_HandleTypeDef huart2;

extern uint8_t temp;
extern int buffer_flag;
extern int index_buffer;
extern char buffer[30];

void first_uart_call(void);
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);

#endif /* INC_WORK_H_ */
