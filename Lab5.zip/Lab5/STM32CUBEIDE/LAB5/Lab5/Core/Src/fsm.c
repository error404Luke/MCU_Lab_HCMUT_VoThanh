#include "fsm.h"
#include "time.h"
#include <stdio.h>
#include <string.h>

extern UART_HandleTypeDef huart2;
extern ADC_HandleTypeDef hadc1;
extern uint8_t temp;

int command_flag = 0; // 1: !RST#, 2: !OK#
int is_sending = 0;
uint32_t adc_value = 0;

// ================= COMMAND PARSER FSM =================
void command_parser_fsm(void) {
	static enum { INIT, EXCLAM, R, S, T, O, K } state = INIT;

	switch (state) {
	case INIT:
		if (temp == '!') state = EXCLAM;
		break;

	case EXCLAM:
		if (temp == 'R') state = R;
		else if (temp == 'O') state = O;
		else state = INIT;
		break;

	case R:
		if (temp == 'S') state = S;
		else state = INIT;
		break;

	case S:
		if (temp == 'T') state = T;
		else state = INIT;
		break;

	case T:
		if (temp == '#') {
			command_flag = 1; // !RST#
			state = INIT;
		} else state = INIT;
		break;

	case O:
		if (temp == 'K') state = K;
		else state = INIT;
		break;

	case K:
		if (temp == '#') {
			command_flag = 2; // !OK#
			state = INIT;
		} else state = INIT;
		break;

	default:
		state = INIT;
		break;
	}
}

// ================= UART COMMUNICATION FSM =================
void uart_communication_fsm(void) {
	if (command_flag == 1) { // !RST#
		adc_value = HAL_ADC_GetValue(&hadc1);
		char msg[50];
		sprintf(msg, "\r!ADC=%lu#\r\n", (unsigned long)adc_value);
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);

		is_sending = 1;
		setTimer1(3000); // bắt đầu đếm timeout
		command_flag = 0;
	}

	if (command_flag == 2) { // !OK#
		is_sending = 0; // dừng gửi
		command_flag = 0;
	}

	// Khi đang gửi mà hết timer => gửi lại gói cũ
	if (is_sending == 1 && timer1_flag == 1) {
		timer1_flag = 0;
		setTimer1(3000);

		char msg[50];
		sprintf(msg, "\r!ADC=%lu#\r\n", (unsigned long)adc_value);
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
	}
}
