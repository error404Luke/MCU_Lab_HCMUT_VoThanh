/*
 * colour.c
 *
 *  Created on: Oct 8, 2025
 *      Author: ACER
 */
#include "colour.h"
int horState = NONE;
int verState = NONE;
void setLedH(int color){
	switch(color){

	case RED:
		HAL_GPIO_WritePin(red_GPIO_Port, red_Pin, LED_ON);
		HAL_GPIO_WritePin(yel_GPIO_Port, yel_Pin, LED_OFF);
		HAL_GPIO_WritePin(green_GPIO_Port, green_Pin, LED_OFF);
		horState = RED;
		break;

	case YEL:

		HAL_GPIO_WritePin(red_GPIO_Port, red_Pin, LED_OFF);
		HAL_GPIO_WritePin(yel_GPIO_Port, yel_Pin, LED_ON);
		HAL_GPIO_WritePin(green_GPIO_Port, green_Pin, LED_OFF);
		horState = YEL;
		break;

	case GRN:

		HAL_GPIO_WritePin(red_GPIO_Port, red_Pin, LED_OFF);
		HAL_GPIO_WritePin(yel_GPIO_Port, yel_Pin, LED_OFF);
		HAL_GPIO_WritePin(green_GPIO_Port, green_Pin, LED_ON);
		horState = GRN;
		break;

	case ALL:

		HAL_GPIO_WritePin(red_GPIO_Port, red_Pin, LED_ON);
		HAL_GPIO_WritePin(yel_GPIO_Port, yel_Pin, LED_ON);
		HAL_GPIO_WritePin(green_GPIO_Port, green_Pin, LED_ON);
		horState = ALL;
		break;

	default:

		HAL_GPIO_WritePin(red_GPIO_Port, red_Pin, LED_OFF);
		HAL_GPIO_WritePin(yel_GPIO_Port, yel_Pin, LED_OFF);
		HAL_GPIO_WritePin(green_GPIO_Port, green_Pin, LED_OFF);
		horState = NONE;
		break;
	}
}

void setLedV(int color){
	switch(color){
	case RED:

		HAL_GPIO_WritePin(red1_GPIO_Port, red1_Pin, LED_ON);
		HAL_GPIO_WritePin(yel1_GPIO_Port, yel1_Pin, LED_OFF);
		HAL_GPIO_WritePin(green1_GPIO_Port, green1_Pin, LED_OFF);
		verState = RED;
		break;

	case YEL:

		HAL_GPIO_WritePin(red1_GPIO_Port, red1_Pin, LED_OFF);
		HAL_GPIO_WritePin(yel1_GPIO_Port, yel1_Pin, LED_ON);
		HAL_GPIO_WritePin(green1_GPIO_Port, green1_Pin, LED_OFF);
		verState = YEL;
		break;

	case GRN:

		HAL_GPIO_WritePin(red1_GPIO_Port, red1_Pin, LED_OFF);
		HAL_GPIO_WritePin(yel1_GPIO_Port, yel1_Pin, LED_OFF);
		HAL_GPIO_WritePin(green1_GPIO_Port, green1_Pin, LED_ON);
		verState = GRN;
		break;

	case ALL:

		HAL_GPIO_WritePin(red1_GPIO_Port, red1_Pin, LED_ON);
		HAL_GPIO_WritePin(yel1_GPIO_Port, yel1_Pin, LED_ON);
		HAL_GPIO_WritePin(green1_GPIO_Port, green1_Pin, LED_ON);
		verState = ALL;
		break;

	default:

		HAL_GPIO_WritePin(red1_GPIO_Port, red1_Pin, LED_OFF);
		HAL_GPIO_WritePin(yel1_GPIO_Port, yel1_Pin, LED_OFF);
		HAL_GPIO_WritePin(green1_GPIO_Port, green1_Pin, LED_OFF);
		verState = NONE;
		break;

	}

}

