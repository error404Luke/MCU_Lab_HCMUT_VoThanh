/*
 * colour.h
 *
 *  Created on: Oct 8, 2025
 *      Author: ACER
 */

#ifndef INC_COLOUR_H_
#define INC_COLOUR_H_

#include "variables.h"

#define LED_ON 0
#define LED_OFF	1

extern int horState;
extern int verState;

void setLedH (int);
void setLedV (int);

#endif /* INC_COLOUR_H_ */
