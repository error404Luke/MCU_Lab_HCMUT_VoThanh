/*
 * input_reading.h
 *
 *  Created on: Oct 5, 2025
 *      Author: ACER
 */

#ifndef INC_INPUT_READING_H_
#define INC_INPUT_READING_H_

#include "variables.h"

#define NO_BUTTON 3
#define PRESSED 0
#define RELEASED 1

int isButtonNoPressed(int);
void buttonRead();
#endif /* INC_INPUT_READING_H_ */
