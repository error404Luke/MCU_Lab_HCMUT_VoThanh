/*
 * four_7_segments.h
 *
 *  Created on: Oct 8, 2025
 *      Author: ACER
 */

#ifndef INC_FOUR_7_SEGMENTS_H_
#define INC_FOUR_7_SEGMENTS_H_

#include "variables.h"

extern int segment_buffer[4];

void set7SegH(int);
void set7SegV(int);
void scan7Seg(int);

void updateSegment(int, int, int, int);
void updateSegment2Digits(int, int);
#endif /* INC_FOUR_7_SEGMENTS_H_ */
