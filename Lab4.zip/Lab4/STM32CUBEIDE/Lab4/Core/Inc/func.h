/*
 * func.h
 *
 *  Created on: Oct 24, 2025
 *      Author: ACER
 */

#ifndef INC_FUNC_H_
#define INC_FUNC_H_

#include "main.h"
#include "stdio.h"
void turnREDLED()
{
	HAL_GPIO_TogglePin(GPIOA, red_led_Pin);
	printf("led red 1 running at: %lu ms\r\n", HAL_GetTick());
}

void turnYELLOWLED()
{
	HAL_GPIO_TogglePin(GPIOA, yellow_led_Pin);
	printf("led yellow running at: %lu ms\r\n", HAL_GetTick());
}

void turnGREENLED()
{
	HAL_GPIO_TogglePin(GPIOA, green_led_Pin);
	printf("led green 1 running at: %lu ms\r\n", HAL_GetTick());
}

void turnRED()
{
	HAL_GPIO_TogglePin(GPIOA, red2_led_Pin);
	printf("led red 2 running at: %lu ms\r\n", HAL_GetTick());
}

void turnGreen()
{
	HAL_GPIO_TogglePin(GPIOA, green2_led_Pin);
	printf("led green 2 running at: %lu ms\r\n", HAL_GetTick());
}

#endif /* INC_FUNC_H_ */
