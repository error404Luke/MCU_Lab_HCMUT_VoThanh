/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define e0_Pin GPIO_PIN_2
#define e0_GPIO_Port GPIOA
#define e1_Pin GPIO_PIN_3
#define e1_GPIO_Port GPIOA
#define r2_Pin GPIO_PIN_10
#define r2_GPIO_Port GPIOB
#define r3_Pin GPIO_PIN_11
#define r3_GPIO_Port GPIOB
#define r4_Pin GPIO_PIN_12
#define r4_GPIO_Port GPIOB
#define r5_Pin GPIO_PIN_13
#define r5_GPIO_Port GPIOB
#define r6_Pin GPIO_PIN_14
#define r6_GPIO_Port GPIOB
#define r7_Pin GPIO_PIN_15
#define r7_GPIO_Port GPIOB
#define e2_Pin GPIO_PIN_10
#define e2_GPIO_Port GPIOA
#define e3_Pin GPIO_PIN_11
#define e3_GPIO_Port GPIOA
#define e4_Pin GPIO_PIN_12
#define e4_GPIO_Port GPIOA
#define e5_Pin GPIO_PIN_13
#define e5_GPIO_Port GPIOA
#define e6_Pin GPIO_PIN_14
#define e6_GPIO_Port GPIOA
#define e7_Pin GPIO_PIN_15
#define e7_GPIO_Port GPIOA
#define r0_Pin GPIO_PIN_8
#define r0_GPIO_Port GPIOB
#define r1_Pin GPIO_PIN_9
#define r1_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
